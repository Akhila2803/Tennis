package TennisScoreBoard;

public class TestingTennis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Players neeraj = new Players();
		Players karthik = new Players();
		Game s = new Game();
		Match m = new Match();
		TennisSet t = new TennisSet();
		neeraj.setScore(40);
		karthik.setScore(60);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
	
		
		//System.out.println("GetScore1:"+neeraj.getScore());
		
		t.updateSet(m, m.getP1(), m.getP2());
		neeraj.setScore(40);
		karthik.setScore(60);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		
		
		//System.out.println("GetScore1:"+neeraj.getScore());
		
		t.updateSet(m, m.getP1(), m.getP2());
		neeraj.setScore(40);
		karthik.setScore(60);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
		neeraj.setScore(60);
		karthik.setScore(40);
		m.updateMatch(neeraj, karthik);
//		System.out.println(m.getP1()+"m.getP1();");
//		System.out.println(m.getP2()+"m.getP2();");
		
		//System.out.println("GetScore1:"+neeraj.getScore());
		
		t.updateSet(m, m.getP1(), m.getP2());
		if(t.setResult(t.p1Sets, t.p2Sets)==1)
		{
			System.out.println("Neeraj won the game!!");
		}
		else {
			System.out.println("Karthik won the game!!");
		}
		
	
		

	}

}
